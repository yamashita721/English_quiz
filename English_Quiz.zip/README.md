# English Grammar Quiz

A comprehensive English grammar quiz application covering various topics including:
- Nouns and Verbs
- Adjectives (Identification, Application, Degree)
- Articles (A, An, The)
- Prepositions
- Question Words
- Contractions and Interjections
- Tenses
- Possession
- And more!

## How to Run

### Requirements
- Python 3.6 or higher

### Instructions
1. Extract the ZIP file
2. Open a terminal/command prompt in the extracted folder
3. Run the following command:
   ```
   python english_quiz.py
   ```

### Features
- Multiple quiz modes (Full Quiz, Shuffled, Difficulty-based)
- Progress tracking
- Detailed results with incorrect answer review
- Category-based performance breakdown
- Easy to use menu system

## Quiz Topics Covered
- Nouns and Main Verbs
- Number and Collection
- Countable and Uncountable Nouns
- Verb Forms and Helping Verbs
- Possessive Nouns and Apostrophes
- Pronouns and Possessive Pronouns
- Adjectives (Identification, Application, Degree)
- Articles (A/An/The)
- Prepositions
- Question Words
- Contractions and Interjections
- Tenses
- Possession

Enjoy practicing your English grammar! 🎓

